


// $(document).ready(function() {
//     $("#phone").mask("+7 (999) 99-99-999");
//   });

$(document).ready(function() {
    // Apply the input mask to the phone input field
    $('#phone').inputmask('7(999) 999-99-99');
});